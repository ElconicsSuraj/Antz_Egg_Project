#ifndef TASK_SERIAL_JSON_H
#define TASK_SERIAL_JSON_H

void Task2(void *pvParameters);
void serialEvent();  // ISR notifier

#endif
