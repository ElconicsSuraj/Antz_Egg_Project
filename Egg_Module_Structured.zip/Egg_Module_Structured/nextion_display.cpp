#include "nextion_display.h"

NexText t0 = NexText(1, 3, "a0");
NexText t1 = NexText(1, 4, "a1");
NexText t2 = NexText(1, 5, "a2");

NexTouch *nex_listen_list[] = { nullptr };

void initNextionTextFields() {
  // Add initialization if needed
}
