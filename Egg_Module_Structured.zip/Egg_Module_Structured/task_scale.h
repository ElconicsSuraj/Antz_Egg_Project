#ifndef TASK_SCALE_H
#define TASK_SCALE_H

void Task1(void *pvParameters);
void tare();
void buttonISR();

#endif
